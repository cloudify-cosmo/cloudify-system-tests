

# configuration 

the following section will explain each key of configuration

__sessionSecret__ 

a key used to encrypt user cookies

__dslParser.virtualenv__

home dir for virtual env where cfy-dsl-parser-cli is available

__dslParser.cliUrl__ - deprecated. ignore. 

__db__

tells the composer's which db to use, will use mongodb by default if it appears, if not will use an embedded db (nedb). 
in case you choose to use mongo, you must install version 3.2.4 and supply the db address as follows:
'mongodb://127.0.0.1:27017/composer' 
if you choose to use nedb just supply the absolute path of where to place the files.


## configuration files

the configuration consists of 2 files: 
 
 - __prod.json__ - found at: `backend/conf/prod.json`
   this file contains all the default values and possible configurations
 - and an overrides file whose location is decided by the value of environment variable `ME_CONF_JSON` - default location is `conf/dev/me.json`


the `dev` folder is ignored by git (see `.gitignore`) to allow writing secret values and make sure you don't accidentally commit them.


checkout cloudify-dsl-parser-cli master branch from:  

Under the composer project , in cloudify-blueprint-composer/backend/conf/ folder create a new folder and name it: ‘dev’, in it create a json file called: me.json 

__deprecated__ : the `cliUrl` configuration is deprecated and will be removed soon. 

